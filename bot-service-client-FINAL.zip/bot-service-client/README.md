# Bots de service client — Essentiel, Pro, Business

Un seul code, trois plans. Chaque client = un fichier dans `clients/`.

| Plan | Prix/mois | Fonctionnement |
|---|---|---|
| Essentiel | 99 $ | Réponses par mots-clés (FAQ), sans mémoire |
| Pro | 199 $ | Gemini, mémoire de 6 échanges, repli sur les mots-clés si panne |
| Business | 349 $ | Gemini, mémoire de 20 échanges, personnalité de marque |

## Contenu du dossier

- `bot.py` : le moteur (les 3 plans)
- `serveur.py` : le serveur web que les sites des clients appellent
- `static/widget.js` : la bulle de clavardage à coller sur le site du client
- `static/logo.svg` : le logo (utilisé par le widget)
- `clients/` : un fichier JSON par client (`_modele.json` = modèle vierge)
- `nouveau_client.py` : crée un client en une commande
- `run.py` : tester un bot dans le terminal
- `Procfile`, `Dockerfile`, `requirements.txt`, `.env.example` : mise en ligne
- `MODELES_LEGAUX.md` : modèles d'entente de service et d'avis de confidentialité

## 1. Tester chez toi

```bash
pip install -r requirements.txt
cp .env.example .env        # puis mets ta clé dans GEMINI_API_KEY
python serveur.py           # ouvre http://localhost:8000/demo
```

Test rapide dans le terminal, sans navigateur : `python run.py clients/clinique_exemple.json`

La clé Gemini s'obtient dans Google AI Studio. Le plan Essentiel fonctionne sans clé.

## 2. Ajouter un client

```bash
python nouveau_client.py --id clinique-abc --nom "Clinique ABC" --plan pro --domaine cliniqueabc.com --serveur https://ton-serveur.com
```

1. Ouvre `clients/clinique-abc.json` et remplis la FAQ, les heures, les infos, le ton.
2. Redéploie (le serveur lit les clients au démarrage).
3. Donne au client la ligne affichée par la commande, à coller avant `</body>` :

```html
<script src="https://ton-serveur.com/widget.js" data-client="clinique-abc" async></script>
```

Champs utiles dans le fichier client :
- `domaines_autorises` : seuls ces sites peuvent utiliser le bot (**toujours le remplir** pour un vrai client)
- `limite_messages_jour` : protège ta facture Gemini
- `couleur` : couleur du widget (ex. `#2F5BEA`)
- `personnalite` : utilisée seulement au plan Business

## 3. Mettre en ligne (Render, Railway ou autre)

1. Mets le dossier dans un dépôt GitHub **privé** (le `.gitignore` exclut déjà `.env`).
2. Crée un « Web Service » sur Render ou Railway lié au dépôt.
3. Commande de démarrage (déjà dans `Procfile`) : `gunicorn serveur:app --threads 8 --bind 0.0.0.0:$PORT`
4. Dans les variables d'environnement de l'hébergeur : `GEMINI_API_KEY` (et au besoin `GEMINI_MODEL`).
5. Vérifie `https://ton-serveur.com/sante` (doit répondre `ok`) puis `https://ton-serveur.com/demo`.

Un `Dockerfile` est aussi fourni si tu préfères Docker.

Limites à connaître :
- Les conversations sont gardées **en mémoire** (30 min d'inactivité), elles disparaissent au redémarrage. C'est voulu : rien n'est stocké, ce qui simplifie la Loi 25.
- Le compteur quotidien est conservé dans `compteurs.json`, donc un simple redémarrage du serveur ne remet pas les limites à zéro. Sur un hébergeur avec plusieurs instances ou un disque éphémère, il faudra plus tard passer à une vraie base de données.
- Si tu es derrière un proxy (Render, Railway, etc.), active `TRUST_PROXY=true` pour que la limitation par IP utilise l'IP réelle du visiteur.
- Si les messages d'un client dépassent la limite, il reçoit un message poli et ça ne te coûte plus rien.

## 4. Te faire payer

- **Stripe** : crée 3 produits avec abonnement mensuel (99 $, 199 $, 349 $), puis envoie au client un **lien de paiement**. Stripe prélève chaque mois automatiquement.
- **Frais d'installation** (optionnel, 200 à 500 $) : ligne unique dans le même lien de paiement.
- Au-dessus de 30 000 $ de revenus sur 12 mois : inscription aux taxes (TPS/TVQ). Valide avec un comptable.
- Avant de fixer tes prix : mesure le coût Gemini réel par conversation avec quelques tests, pour confirmer tes marges.

## 5. Avant de signer un client

- [ ] Remplir `domaines_autorises`
- [ ] Faire signer l'entente de service (modèle dans `MODELES_LEGAUX.md`)
- [ ] Fournir au client l'avis de confidentialité à ajouter sur son site (modèle fourni)
- [ ] Tester le bot avec 20 vraies questions du client, y compris des questions piège
- [ ] Configurer le paiement Stripe

## Dépannage

- « Client inconnu » : le fichier n'est pas dans `clients/`, son nom commence par `_`, ou le serveur n'a pas été redémarré.
- « Domaine non autorisé » : le site du client n'est pas dans `domaines_autorises`.
- Les plans Pro/Business répondent comme l'Essentiel : la clé Gemini est absente ou invalide (voir les messages `[avertissement]` dans les logs).
